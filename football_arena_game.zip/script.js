const canvas = document.getElementById("pitch");
const ctx = canvas.getContext("2d");
const homeScoreEl = document.getElementById("homeScore");
const awayScoreEl = document.getElementById("awayScore");
const timerEl = document.getElementById("timer");
const messageEl = document.getElementById("message");
const difficultyEl = document.getElementById("difficulty");

let W = 1000, H = 600, playing = true, matchTime = 90;
let last = performance.now(), flash = 0, goalPause = 0;
const keys = {};
const joy = {x:0, y:0, active:false};

const player = {x:220, y:300, r:17, speed:240, vx:0, vy:0, angle:0, hasBall:true, sprint:false};
const ball = {x:245, y:300, r:8, vx:0, vy:0, owner:"player"};
const keeper = {x:850, y:300, r:20, vx:0, vy:0};
const defenders = [
  {x:650,y:190,r:17,vx:0,vy:0},
  {x:690,y:410,r:17,vx:0,vy:0},
  {x:770,y:300,r:17,vx:0,vy:0}
];
let homeScore=0, awayScore=0;

function resize(){
  const dpr=Math.min(devicePixelRatio||1,2);
  const rect=canvas.getBoundingClientRect();
  W=rect.width; H=rect.height;
  canvas.width=W*dpr; canvas.height=H*dpr;
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
window.addEventListener("resize",resize); resize();

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y);}
function norm(x,y){const m=Math.hypot(x,y)||1;return {x:x/m,y:y/m};}

function field(){
  ctx.clearRect(0,0,W,H);
  const m=Math.min(W,H)*0.055, x=m, y=m*.65, w=W-2*m, h=H-2*m*1.1;
  ctx.fillStyle="#08752f"; ctx.fillRect(x,y,w,h);
  for(let i=0;i<10;i++){ctx.fillStyle=i%2?"#087d33":"#08752f";ctx.fillRect(x+i*w/10,y,w/10,h);}
  ctx.strokeStyle="#eaf9e9"; ctx.lineWidth=3;
  ctx.strokeRect(x,y,w,h);
  ctx.beginPath();ctx.moveTo(x+w/2,y);ctx.lineTo(x+w/2,y+h);ctx.stroke();
  ctx.beginPath();ctx.arc(x+w/2,y+h/2,Math.min(w,h)*.13,0,Math.PI*2);ctx.stroke();
  ctx.beginPath();ctx.arc(x+w/2,y+h/2,3,0,Math.PI*2);ctx.fillStyle="#fff";ctx.fill();
  // penalty boxes
  const boxW=w*.16, boxH=h*.42;
  ctx.strokeRect(x,y+h/2-boxH/2,boxW,boxH);
  ctx.strokeRect(x+w-boxW,y+h/2-boxH/2,boxW,boxH);
  ctx.strokeRect(x,y+h/2-boxH*.62,boxW*.42,boxH*1.24);
  ctx.strokeRect(x+w-boxW*.42,y+h/2-boxH*.62,boxW*.42,boxH*1.24);
  ctx.fillStyle="#fff";ctx.fillRect(x-10,y+h/2-38,10,76);ctx.fillRect(x+w,y+h/2-38,10,76);
  return {x,y,w,h};
}

function circle(o,color,outline="#fff"){
  ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();
  ctx.strokeStyle=outline;ctx.lineWidth=2;ctx.stroke();
}
function drawBall(){circle(ball,"#fff","#333");ctx.beginPath();ctx.arc(ball.x-2,ball.y-2,2,0,Math.PI*2);ctx.fillStyle="#222";ctx.fill();}
function draw(){
  const f=field();
  // shadows
  [...defenders,keeper,player].forEach(o=>{ctx.beginPath();ctx.ellipse(o.x,o.y+o.r*.75,o.r*1.15,o.r*.38,0,0,Math.PI*2);ctx.fillStyle="#0005";ctx.fill();});
  defenders.forEach(d=>circle(d,"#e43d3d"));
  circle(keeper,"#ffd23f");
  circle(player,"#2c8cff");
  // direction arrow
  ctx.beginPath();ctx.moveTo(player.x,player.y);ctx.lineTo(player.x+Math.cos(player.angle)*28,player.y+Math.sin(player.angle)*28);
  ctx.strokeStyle="#fff";ctx.lineWidth=4;ctx.stroke();
  drawBall();
  if(flash>0){ctx.fillStyle=`rgba(255,255,255,${flash*.4})`;ctx.fillRect(0,0,W,H);}
}

function input(){
  let x=0,y=0;
  if(keys.ArrowLeft||keys.a)x--; if(keys.ArrowRight||keys.d)x++;
  if(keys.ArrowUp||keys.w)y--; if(keys.ArrowDown||keys.s)y++;
  x+=joy.x; y+=joy.y;
  const n=norm(x,y);
  return (x||y)?n:{x:0,y:0};
}

function shoot(){
  if(!playing || goalPause>0) return;
  const near=dist(player,ball)<55;
  if(!near) return;
  player.hasBall=false; ball.owner=null;
  const target={x:W-35,y:H/2+(Math.random()-.5)*110};
  const n=norm(target.x-ball.x,target.y-ball.y);
  ball.vx=n.x*650; ball.vy=n.y*650;
}
function pass(){
  if(!playing || !player.hasBall)return;
  player.hasBall=false;ball.owner=null;
  const target=defenders.reduce((a,b)=>dist(a,player)<dist(b,player)?a:b);
  const n=norm(target.x-player.x,target.y-player.y);
  ball.x=player.x+n.x*25;ball.y=player.y+n.y*25;
  ball.vx=n.x*420;ball.vy=n.y*420;
}
function resetPositions(){
  player.x=W*.22;player.y=H/2;player.angle=0;player.hasBall=true;
  ball.x=player.x+25;ball.y=player.y;ball.vx=ball.vy=0;ball.owner="player";
  defenders[0].x=W*.62;defenders[0].y=H*.32;
  defenders[1].x=W*.67;defenders[1].y=H*.68;
  defenders[2].x=W*.76;defenders[2].y=H/2;
  keeper.x=W*.87;keeper.y=H/2;
}
function goal(us){
  if(us)homeScore++;else awayScore++;
  homeScoreEl.textContent=homeScore;awayScoreEl.textContent=awayScore;
  messageEl.textContent=us?"GOAL! ⚽":"THE AI SCORES!";
  messageEl.style.opacity=1;goalPause=1.6;flash=1;
  setTimeout(()=>{messageEl.style.opacity=0;resetPositions();},900);
}
function update(dt){
  if(!playing)return;
  if(goalPause>0){goalPause-=dt;return;}
  matchTime-=dt;if(matchTime<=0){matchTime=0;playing=false;messageEl.textContent="FULL TIME";messageEl.style.opacity=1;}
  const mm=Math.floor(matchTime/60), ss=Math.floor(matchTime%60);
  timerEl.textContent=`${String(mm).padStart(2,"0")}:${String(ss).padStart(2,"0")}`;

  const inp=input();
  const sprint=keys.Shift||player.sprint;
  const speed=player.speed*(sprint?1.45:1);
  player.vx=inp.x*speed;player.vy=inp.y*speed;
  player.x+=player.vx*dt;player.y+=player.vy*dt;
  player.angle=Math.atan2(inp.y,inp.x)||player.angle;

  const margin=Math.min(W,H)*.055;
  player.x=clamp(player.x,margin+18,W-margin-18);player.y=clamp(player.y,margin*.65+18,H-margin*1.1-18);

  if(player.hasBall){ball.x=player.x+Math.cos(player.angle)*25;ball.y=player.y+Math.sin(player.angle)*25;}
  else {
    ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;
    ball.vx*=Math.pow(.035,dt);ball.vy*=Math.pow(.035,dt);
    if(ball.x<margin){ball.x=margin;ball.vx*=-.5}
    if(ball.x>W-margin){if(Math.abs(ball.y-H/2)<65){goal(true);return}else{ball.x=W-margin;ball.vx*=-.5}}
    if(ball.y<margin*.65){ball.y=margin*.65;ball.vy*=-.6}
    if(ball.y>H-margin*1.1){ball.y=H-margin*1.1;ball.vy*=-.6}
    if(dist(player,ball)<30 && Math.hypot(ball.vx,ball.vy)<170){player.hasBall=true;ball.owner="player";}
  }

  const diff=difficultyEl.value;
  const aiSpeed=diff==="easy"?105:diff==="hard"?185:145;
  defenders.forEach((d,i)=>{
    const target=i===2?ball:player;
    const n=norm(target.x-d.x,target.y-d.y);
    d.vx=n.x*aiSpeed;d.vy=n.y*aiSpeed;d.x+=d.vx*dt;d.y+=d.vy*dt;
    d.x=clamp(d.x,margin+18,W-margin-18);d.y=clamp(d.y,margin*.65+18,H-margin*1.1-18);
    if(dist(d,player)<d.r+player.r+3 && player.hasBall){
      player.hasBall=false;ball.owner=null;ball.x=player.x;ball.y=player.y;
      const kick=norm(W*.72-ball.x,H/2-ball.y);ball.vx=kick.x*250;ball.vy=kick.y*250;
    }
  });
  // Keeper tracks the ball, with difficulty affecting speed.
  const kn=norm(ball.x-keeper.x,ball.y-keeper.y);
  keeper.y+=kn.y*(diff==="hard"?210:diff==="normal"?165:125)*dt;
  keeper.y=clamp(keeper.y,H/2-95,H/2+95);
  if(dist(keeper,ball)<keeper.r+ball.r+5 && !player.hasBall){
    ball.vx=-Math.abs(ball.vx)*.8-120; ball.vy=(ball.y-keeper.y)*4;
  }
  flash=Math.max(0,flash-dt*2.5);
}
function loop(now){const dt=Math.min(.033,(now-last)/1000);last=now;update(dt);draw();requestAnimationFrame(loop);}
requestAnimationFrame(loop);

window.addEventListener("keydown",e=>{keys[e.key]=true;if(e.code==="Space"){e.preventDefault();shoot()}if(e.key.toLowerCase()==="e")pass()});
window.addEventListener("keyup",e=>keys[e.key]=false);
document.getElementById("shootBtn").addEventListener("pointerdown",e=>{e.preventDefault();shoot()});
document.getElementById("passBtn").addEventListener("pointerdown",e=>{e.preventDefault();pass()});
document.getElementById("sprintBtn").addEventListener("pointerdown",e=>{e.preventDefault();player.sprint=true});
["pointerup","pointercancel","pointerleave"].forEach(t=>document.getElementById("sprintBtn").addEventListener(t,()=>player.sprint=false));
document.getElementById("pauseBtn").onclick=()=>{playing=!playing;document.getElementById("pauseBtn").textContent=playing?"Pause":"Resume"};
document.getElementById("restartBtn").onclick=()=>{homeScore=awayScore=0;matchTime=90;homeScoreEl.textContent=awayScoreEl.textContent="0";messageEl.style.opacity=0;playing=true;resetPositions()};
const joystick=document.getElementById("joystick"),stick=document.getElementById("stick");
function setJoy(e){const r=joystick.getBoundingClientRect();let x=e.clientX-(r.left+r.width/2),y=e.clientY-(r.top+r.height/2);const m=Math.min(40,Math.hypot(x,y));const n=norm(x,y);joy.x=n.x*(m/40);joy.y=n.y*(m/40);stick.style.transform=`translate(${joy.x*40}px,${joy.y*40}px)`;}
joystick.addEventListener("pointerdown",e=>{joy.active=true;joystick.setPointerCapture(e.pointerId);setJoy(e)});
joystick.addEventListener("pointermove",e=>{if(joy.active)setJoy(e)});
joystick.addEventListener("pointerup",()=>{joy.active=false;joy.x=joy.y=0;stick.style.transform="translate(0,0)"});
resetPositions();
